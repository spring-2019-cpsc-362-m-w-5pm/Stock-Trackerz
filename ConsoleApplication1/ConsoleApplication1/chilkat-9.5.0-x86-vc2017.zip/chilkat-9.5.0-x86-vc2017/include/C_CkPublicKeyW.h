// This is a generated source file for Chilkat version 9.5.0.77
#ifndef _C_CkPublicKeyWH
#define _C_CkPublicKeyWH
#include "chilkatDefs.h"

#include "Chilkat_C.h"


CK_VISIBLE_PUBLIC HCkPublicKeyW CkPublicKeyW_Create(void);
CK_VISIBLE_PUBLIC void CkPublicKeyW_Dispose(HCkPublicKeyW handle);
CK_VISIBLE_PUBLIC void CkPublicKeyW_getDebugLogFilePath(HCkPublicKeyW cHandle, HCkString retval);
CK_VISIBLE_PUBLIC void  CkPublicKeyW_putDebugLogFilePath(HCkPublicKeyW cHandle, const wchar_t *newVal);
CK_VISIBLE_PUBLIC const wchar_t *CkPublicKeyW_debugLogFilePath(HCkPublicKeyW cHandle);
CK_VISIBLE_PUBLIC int CkPublicKeyW_getKeySize(HCkPublicKeyW cHandle);
CK_VISIBLE_PUBLIC void CkPublicKeyW_getKeyType(HCkPublicKeyW cHandle, HCkString retval);
CK_VISIBLE_PUBLIC const wchar_t *CkPublicKeyW_keyType(HCkPublicKeyW cHandle);
CK_VISIBLE_PUBLIC void CkPublicKeyW_getLastErrorHtml(HCkPublicKeyW cHandle, HCkString retval);
CK_VISIBLE_PUBLIC const wchar_t *CkPublicKeyW_lastErrorHtml(HCkPublicKeyW cHandle);
CK_VISIBLE_PUBLIC void CkPublicKeyW_getLastErrorText(HCkPublicKeyW cHandle, HCkString retval);
CK_VISIBLE_PUBLIC const wchar_t *CkPublicKeyW_lastErrorText(HCkPublicKeyW cHandle);
CK_VISIBLE_PUBLIC void CkPublicKeyW_getLastErrorXml(HCkPublicKeyW cHandle, HCkString retval);
CK_VISIBLE_PUBLIC const wchar_t *CkPublicKeyW_lastErrorXml(HCkPublicKeyW cHandle);
CK_VISIBLE_PUBLIC BOOL CkPublicKeyW_getLastMethodSuccess(HCkPublicKeyW cHandle);
CK_VISIBLE_PUBLIC void  CkPublicKeyW_putLastMethodSuccess(HCkPublicKeyW cHandle, BOOL newVal);
CK_VISIBLE_PUBLIC BOOL CkPublicKeyW_getVerboseLogging(HCkPublicKeyW cHandle);
CK_VISIBLE_PUBLIC void  CkPublicKeyW_putVerboseLogging(HCkPublicKeyW cHandle, BOOL newVal);
CK_VISIBLE_PUBLIC void CkPublicKeyW_getVersion(HCkPublicKeyW cHandle, HCkString retval);
CK_VISIBLE_PUBLIC const wchar_t *CkPublicKeyW_version(HCkPublicKeyW cHandle);
CK_VISIBLE_PUBLIC BOOL CkPublicKeyW_GetDer(HCkPublicKeyW cHandle, BOOL preferPkcs1, HCkByteData outBytes);
CK_VISIBLE_PUBLIC BOOL CkPublicKeyW_GetEncoded(HCkPublicKeyW cHandle, BOOL preferPkcs1, const wchar_t *encoding, HCkString outStr);
CK_VISIBLE_PUBLIC const wchar_t *CkPublicKeyW_getEncoded(HCkPublicKeyW cHandle, BOOL preferPkcs1, const wchar_t *encoding);
CK_VISIBLE_PUBLIC BOOL CkPublicKeyW_GetJwk(HCkPublicKeyW cHandle, HCkString outStr);
CK_VISIBLE_PUBLIC const wchar_t *CkPublicKeyW_getJwk(HCkPublicKeyW cHandle);
CK_VISIBLE_PUBLIC BOOL CkPublicKeyW_GetJwkThumbprint(HCkPublicKeyW cHandle, const wchar_t *hashAlg, HCkString outStr);
CK_VISIBLE_PUBLIC const wchar_t *CkPublicKeyW_getJwkThumbprint(HCkPublicKeyW cHandle, const wchar_t *hashAlg);
CK_VISIBLE_PUBLIC BOOL CkPublicKeyW_GetOpenSslDer(HCkPublicKeyW cHandle, HCkByteData outData);
CK_VISIBLE_PUBLIC BOOL CkPublicKeyW_GetOpenSslPem(HCkPublicKeyW cHandle, HCkString outStr);
CK_VISIBLE_PUBLIC const wchar_t *CkPublicKeyW_getOpenSslPem(HCkPublicKeyW cHandle);
CK_VISIBLE_PUBLIC BOOL CkPublicKeyW_GetPem(HCkPublicKeyW cHandle, BOOL preferPkcs1, HCkString outStr);
CK_VISIBLE_PUBLIC const wchar_t *CkPublicKeyW_getPem(HCkPublicKeyW cHandle, BOOL preferPkcs1);
CK_VISIBLE_PUBLIC BOOL CkPublicKeyW_GetPkcs1ENC(HCkPublicKeyW cHandle, const wchar_t *encoding, HCkString outStr);
CK_VISIBLE_PUBLIC const wchar_t *CkPublicKeyW_getPkcs1ENC(HCkPublicKeyW cHandle, const wchar_t *encoding);
CK_VISIBLE_PUBLIC BOOL CkPublicKeyW_GetPkcs8ENC(HCkPublicKeyW cHandle, const wchar_t *encoding, HCkString outStr);
CK_VISIBLE_PUBLIC const wchar_t *CkPublicKeyW_getPkcs8ENC(HCkPublicKeyW cHandle, const wchar_t *encoding);
CK_VISIBLE_PUBLIC BOOL CkPublicKeyW_GetRsaDer(HCkPublicKeyW cHandle, HCkByteData outData);
CK_VISIBLE_PUBLIC BOOL CkPublicKeyW_GetXml(HCkPublicKeyW cHandle, HCkString outStr);
CK_VISIBLE_PUBLIC const wchar_t *CkPublicKeyW_getXml(HCkPublicKeyW cHandle);
CK_VISIBLE_PUBLIC BOOL CkPublicKeyW_LoadBase64(HCkPublicKeyW cHandle, const wchar_t *keyStr);
CK_VISIBLE_PUBLIC BOOL CkPublicKeyW_LoadFromBinary(HCkPublicKeyW cHandle, HCkByteData keyBytes);
CK_VISIBLE_PUBLIC BOOL CkPublicKeyW_LoadFromFile(HCkPublicKeyW cHandle, const wchar_t *path);
CK_VISIBLE_PUBLIC BOOL CkPublicKeyW_LoadFromString(HCkPublicKeyW cHandle, const wchar_t *keyString);
CK_VISIBLE_PUBLIC BOOL CkPublicKeyW_LoadOpenSslDer(HCkPublicKeyW cHandle, HCkByteData data);
CK_VISIBLE_PUBLIC BOOL CkPublicKeyW_LoadOpenSslDerFile(HCkPublicKeyW cHandle, const wchar_t *path);
CK_VISIBLE_PUBLIC BOOL CkPublicKeyW_LoadOpenSslPem(HCkPublicKeyW cHandle, const wchar_t *str);
CK_VISIBLE_PUBLIC BOOL CkPublicKeyW_LoadOpenSslPemFile(HCkPublicKeyW cHandle, const wchar_t *path);
CK_VISIBLE_PUBLIC BOOL CkPublicKeyW_LoadPkcs1Pem(HCkPublicKeyW cHandle, const wchar_t *str);
CK_VISIBLE_PUBLIC BOOL CkPublicKeyW_LoadRsaDer(HCkPublicKeyW cHandle, HCkByteData data);
CK_VISIBLE_PUBLIC BOOL CkPublicKeyW_LoadRsaDerFile(HCkPublicKeyW cHandle, const wchar_t *path);
CK_VISIBLE_PUBLIC BOOL CkPublicKeyW_LoadXml(HCkPublicKeyW cHandle, const wchar_t *xml);
CK_VISIBLE_PUBLIC BOOL CkPublicKeyW_LoadXmlFile(HCkPublicKeyW cHandle, const wchar_t *path);
CK_VISIBLE_PUBLIC BOOL CkPublicKeyW_SaveDerFile(HCkPublicKeyW cHandle, BOOL preferPkcs1, const wchar_t *path);
CK_VISIBLE_PUBLIC BOOL CkPublicKeyW_SaveLastError(HCkPublicKeyW cHandle, const wchar_t *path);
CK_VISIBLE_PUBLIC BOOL CkPublicKeyW_SaveOpenSslDerFile(HCkPublicKeyW cHandle, const wchar_t *path);
CK_VISIBLE_PUBLIC BOOL CkPublicKeyW_SaveOpenSslPemFile(HCkPublicKeyW cHandle, const wchar_t *path);
CK_VISIBLE_PUBLIC BOOL CkPublicKeyW_SavePemFile(HCkPublicKeyW cHandle, BOOL preferPkcs1, const wchar_t *path);
CK_VISIBLE_PUBLIC BOOL CkPublicKeyW_SaveRsaDerFile(HCkPublicKeyW cHandle, const wchar_t *path);
CK_VISIBLE_PUBLIC BOOL CkPublicKeyW_SaveXmlFile(HCkPublicKeyW cHandle, const wchar_t *path);
#endif
